const categories=[
 {name:"Electrician",icon:"⚡",desc:"Electrical repairs and installation"},
 {name:"Plumber",icon:"🔧",desc:"Pipes, taps and water systems"},
 {name:"Carpenter",icon:"🪚",desc:"Furniture and woodwork"},
 {name:"Home Cleaning",icon:"🧹",desc:"Home and office cleaning"},
 {name:"Painting",icon:"🖌️",desc:"Painting and finishing"},
 {name:"Contractor",icon:"🏗️",desc:"Construction and renovation"}
];
const services=[
 {name:"Electrician",icon:"⚡",desc:"Electrical repairs, wiring and installations.",category:"Electrician",type:"Home service"},
 {name:"Plumber",icon:"🔧",desc:"Tap repairs, pipe fitting and water connections.",category:"Plumber",type:"Home service"},
 {name:"Carpenter",icon:"🪚",desc:"Furniture repair, fitting and custom woodwork.",category:"Carpenter",type:"Home service"},
 {name:"Home Cleaning",icon:"🧹",desc:"Cleaning support for homes and workplaces.",category:"Home Cleaning",type:"Home service"},
 {name:"Painter",icon:"🖌️",desc:"Interior and exterior painting services.",category:"Painting",type:"Home service"},
 {name:"Building Contractor",icon:"🏗️",desc:"Construction, renovation and repair projects.",category:"Contractor",type:"Professional service"},
 {name:"Appliance Repair",icon:"🛠️",desc:"General household appliance repair support.",category:"Other",type:"Repair service"},
 {name:"AC Service",icon:"❄️",desc:"Air-conditioner maintenance and servicing.",category:"Other",type:"Repair service"},
 {name:"Computer Service",icon:"💻",desc:"Computer setup and basic technical support.",category:"Other",type:"Technical service"}
];
const shops=[
 {name:"Grocery & Daily Needs",icon:"🛒",desc:"Everyday essentials from neighbourhood stores.",kind:"Grocery"},
 {name:"Mobile & Electronics",icon:"📱",desc:"Mobile accessories and electronic products.",kind:"Electronics"},
 {name:"Hardware Store",icon:"🧰",desc:"Tools, fittings and home improvement supplies.",kind:"Hardware"},
 {name:"Stationery Shop",icon:"📚",desc:"School, office and stationery essentials.",kind:"Stationery"},
 {name:"Clothing Store",icon:"👕",desc:"Clothing and everyday fashion items.",kind:"Clothing"},
 {name:"Pharmacy",icon:"＋",desc:"A sample category for licensed local pharmacies.",kind:"Pharmacy"}
];
const $=s=>document.querySelector(s);
function card(item,kind){return `<article class="listing-card"><div class="listing-top"><div class="listing-icon">${item.icon}</div><span class="sample-tag">SAMPLE LISTING</span></div><h3>${item.name}</h3><p>${item.desc}</p><div class="listing-bottom"><span>${kind}</span><b>Details coming soon ↗</b></div></article>`}
function renderCategories(){ $("#categoryGrid").innerHTML=categories.map(c=>`<button class="category-card" data-category="${c.name}"><span class="category-icon">${c.icon}</span><b>${c.name}</b></button>`).join("");}
function renderServices(list=services,target="#servicesGrid"){ $(target).innerHTML=list.length?list.map(x=>card(x,x.type)).join(""):`<div class="empty-state">No matching services found. Try another search.</div>`;}
function renderShops(list=shops){ $("#shopsGrid").innerHTML=list.length?list.map(x=>card(x,x.kind)).join(""):`<div class="empty-state">No matching shops found. Try another search.</div>`;}
function showPage(id){const valid=["home","services","shops","about"].includes(id)?id:"home";document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active-page",p.id===valid));document.querySelectorAll("[data-page]").forEach(a=>a.classList.toggle("active",a.dataset.page===valid));if(location.hash!=="#"+valid)history.replaceState(null,"","#"+valid);window.scrollTo({top:0,behavior:"smooth"});}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200);}
document.addEventListener("click",e=>{const nav=e.target.closest("[data-page]");if(nav){e.preventDefault();showPage(nav.dataset.page);return;}const cat=e.target.closest("[data-category]");if(cat){$("#serviceFilter").value=cat.dataset.category;$("#serviceSearch").value="";renderServices(services.filter(s=>s.category===cat.dataset.category));showPage("services");}});
$("#serviceSearch").addEventListener("input",e=>{const q=e.target.value.toLowerCase();const c=$("#serviceFilter").value;renderServices(services.filter(s=>(c==="all"||s.category===c)&&(s.name+" "+s.desc+" "+s.category).toLowerCase().includes(q)));});
$("#serviceFilter").addEventListener("change",()=>$("#serviceSearch").dispatchEvent(new Event("input")));
$("#shopSearch").addEventListener("input",e=>{const q=e.target.value.toLowerCase();renderShops(shops.filter(s=>(s.name+" "+s.desc+" "+s.kind).toLowerCase().includes(q)));});
$("#locationBtn").addEventListener("click",()=>{const current=$("#locationLabel").textContent;const place=prompt("Enter your city, town or area (this preview does not verify location):",current==="Set location"?"":current);if(place&&place.trim()){$("#locationLabel").textContent=place.trim();toast("Location label updated for this preview.");}});
$("#year").textContent=new Date().getFullYear();
$("#serviceFilter").innerHTML='<option value="all">All categories</option>'+categories.map(c=>`<option value="${c.name}">${c.name}</option>`).join("");
renderCategories();renderServices(services,"#homeServices");renderServices();renderShops();
showPage(location.hash.slice(1)||"home");
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));
